function a = inverse_interpolation(x0, x1, x2, y0, y1, y2)
% Wykonuje interpolację odwrotną za pomocą wielomianu Newtona, obliczając 
% nowe przybliżenie miejsca zerowego.
% Funkcja przyjmuje sześć argumentów: trzy punkty x (x0, x1, x2) i 
% wartości funkcji f w tych punktach (y0, y1, y2).
% Na początku obliczane są różnice dzielone pierwszego i drugiego rzędu 
% (d01, d12, d012).
% Następnie, za pomocą formuły Newtona dla interpolacji odwrotnej, 
% wyliczane jest nowe przybliżenie miejsca zerowego 'a'.
% Autor: Andrii Voznesenskyi

d01 = (y0 - y1) / (x0 - x1);
d12 = (y1 - y2) / (x1 - x2);
d012 = (d01 - d12) / (x0 - x2);
a = x0 - y0 / (d01 - (y0 - y1) * d012);
end